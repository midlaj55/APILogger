//
//  User.swift
//  APILoggerDemo
//
//  Created by Midlaj Mc on 26/03/26.
//

import Foundation

struct User: Codable {
    let id: Int
    let name: String
    let email: String
}
