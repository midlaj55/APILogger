//
//  APILogger.swift
//  APILoggerDemo
//
//  Created by Midlaj Mc on 26/03/26.
//

import Foundation
import Alamofire
import os

final class APILogger: EventMonitor {

    let queue = DispatchQueue(label: "com.api.logger")
    private let logger = Logger(subsystem: "APILoggerDemo", category: "Networking")

    func requestDidResume(_ request: Request) {
        logRequest(request)
    }

    func request<Value>(_ request: DataRequest,
                        didParseResponse response: DataResponse<Value, AFError>) {

        logResponse(request: request, response: response)
    }
}

// MARK: - Private Methods
private extension APILogger {

    func logRequest(_ request: Request) {
        guard let urlRequest = request.request else { return }

        var log = "\n🚀 REQUEST\n"
        log += "\(urlRequest.httpMethod ?? "") \(urlRequest.url?.absoluteString ?? "")\n"
        log += "Headers: \(urlRequest.allHTTPHeaderFields ?? [:])\n"

        if let body = urlRequest.httpBody {
            log += "Body: \(prettyJSON(from: body))\n"
        }

        logger.info("\(log)")
    }

    func logResponse<Value>(request: DataRequest,
                            response: DataResponse<Value, AFError>) {

        var log = "\n📥 RESPONSE\n"
        log += "\(request.request?.url?.absoluteString ?? "")\n"
        log += "Status Code: \(response.response?.statusCode ?? 0)\n"

        if let data = response.data {
            log += "Response: \(prettyJSON(from: data))\n"
        }

        switch response.result {
        case .success:
            logger.info("\(log)")
        case .failure(let error):
            log += "❌ Error: \(error.localizedDescription)\n"
            logger.error("\(log)")
        }
    }

    func prettyJSON(from data: Data) -> String {
        guard
            let object = try? JSONSerialization.jsonObject(with: data),
            let prettyData = try? JSONSerialization.data(withJSONObject: object, options: .prettyPrinted),
            let prettyString = String(data: prettyData, encoding: .utf8)
        else {
            return String(data: data, encoding: .utf8) ?? "Invalid JSON"
        }
        return prettyString
    }
}
