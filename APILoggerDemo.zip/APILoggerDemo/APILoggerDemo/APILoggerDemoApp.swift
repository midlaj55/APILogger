//
//  APILoggerDemoApp.swift
//  APILoggerDemo
//
//  Created by Midlaj Mc on 26/03/26.
//

import SwiftUI

@main
struct APILoggerDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
