//
//  ContentView.swift
//  APILoggerDemo
//
//  Created by Midlaj Mc on 26/03/26.
//

import SwiftUI

struct ContentView: View {

    @StateObject var viewModel = HomeViewModel()

    var body: some View {
        NavigationView {
            List(viewModel.users, id: \.id) { user in
                VStack(alignment: .leading) {
                    Text(user.name).font(.headline)
                    Text(user.email).font(.subheadline)
                }
            }
            .navigationTitle("Users")
            .onAppear {
                viewModel.fetchUsers()
            }
        }
    }
}

#Preview {
    ContentView()
}
