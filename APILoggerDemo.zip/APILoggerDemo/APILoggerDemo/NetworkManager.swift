//
//  NetworkManager.swift
//  APILoggerDemo
//
//  Created by Midlaj Mc on 26/03/26.
//

import Alamofire

final class NetworkManager {

    static let shared = NetworkManager()

    private let session: Session

    private init() {
        session = Session(
            eventMonitors: [APILogger()] // ✅ Attach logger here
        )
    }

    func request<T: Decodable>(
        _ url: String,
        completion: @escaping (Result<T, AFError>) -> Void
    ) {
        session.request(url)
            .validate()
            .responseDecodable(of: T.self) { response in
                completion(response.result)
            }
    }
}
