//
//  HomeViewModel.swift
//  APILoggerDemo
//
//  Created by Midlaj Mc on 26/03/26.
//

import Foundation
import Alamofire
import Combine

class HomeViewModel: ObservableObject {

    @Published var users: [User] = []
    @Published var isLoading = false

    func fetchUsers() {
        isLoading = true

        NetworkManager.shared.request(
            "https://jsonplaceholder.typicode.com/users"
        ) { [weak self] (result: Result<[User], AFError>) in

            DispatchQueue.main.async {
                self?.isLoading = false

                switch result {
                case .success(let data):
                    self?.users = data
                case .failure(let error):
                    print("Error:", error.localizedDescription)
                }
            }
        }
    }
}
